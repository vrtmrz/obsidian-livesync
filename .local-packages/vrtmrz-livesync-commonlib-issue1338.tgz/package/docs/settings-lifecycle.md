# Settings lifecycle

Commonlib separates three values which older integrations commonly treated as one object:

- `SETTINGS_SCHEMA_DEFAULTS` completes keys which are absent from stored settings. Its values remain conservative so that an upgrade does not silently change an existing choice.
- `NEW_VAULT_SETTINGS` initialises a store which has never contained Self-hosted LiveSync settings. It includes the current recommended base values.
- the `PREFERRED_SETTING_*` objects add remote-specific recommendations when a user explicitly selects Cloudant, self-hosted CouchDB, or Object Storage during setup.

`DEFAULT_SETTINGS` remains an alias of `SETTINGS_SCHEMA_DEFAULTS` for compatibility. New code should choose the named contract which matches its operation.

## Starting a new Vault

Use `createNewVaultSettings()` only when the settings store is absent or empty, or when the user explicitly requests a factory reset. `NEW_VAULT_SETTINGS` exposes the values for inspection, while the factory prevents mutable nested settings from being shared between clients:

```ts
import { createNewVaultSettings } from "@vrtmrz/livesync-commonlib/settings";

const initialSettings = createNewVaultSettings();
```

The recommended base currently selects a 50 MB maximum synchronised file size, a `customChunkSize` value of 0, Rabin–Karp chunk splitting, Plug-in Sync V2, case-insensitive file-name handling, and E2EE V2. Chunk revisions are always derived from their content; the obsolete `doNotUseFixedRevisionForChunks` stored key is retained only for compatibility and is not a recommendation or tweak. The recommended base does not enable synchronisation or encryption on behalf of the user.

Compared with the conservative stored-setting fallbacks, the current new-Vault object has exactly two semantic differences:

| Setting | Existing stored setting is absent | New Vault |
| --- | --- | --- |
| `usePluginSyncV2` | `false` | `true` |
| `handleFilenameCaseSensitive` | normalised from the legacy absent value to `false` | `false` |

The other headline recommendations are already the conservative fallbacks: `syncMaxSizeInMB` is 50, `customChunkSize` is 0, `chunkSplitterVersion` is `v3-rabin-karp`, and `E2EEAlgorithm` is `v2`. Data Compression, Eden, V1 dynamic iteration, the legacy IndexedDB adapter, Hidden File Sync, and automatic synchronisation remain disabled when their stored values are absent. Explicit stored values take precedence.

Apply a remote-specific preferred object only while configuring that remote. Do not merge it into an existing stored configuration merely because the remote type can be inferred. Cloudant, self-hosted CouchDB, and Journal Sync setup all use the common `customChunkSize` value of 0. Their unrelated request and bulk settings remain service-specific. The current Doctor regulation no longer recommends changing the value to 60 universally, and existing explicit values remain valid.

The new Doctor rule set inherits 1.0.33 and withdraws the Chunk-size rule with
`customChunkSize: undefined`. Historical regulations keep their original rules.
This removes the recommendation, rather than deleting a stored setting or
forcing it to 0. Its consultation version deliberately remains 1.0.33: removing
a recommendation does not require users to review unchanged recommendations
again. Existing dismissals remain effective; an explicit forced rescan still
checks the remaining rules.

| Explicitly selected remote | `customChunkSize` | `concurrencyOfReadChunksOnline` | `minimumIntervalOfReadChunksOnline` |
| --- | ---: | ---: | ---: |
| Cloudant | 0 | 100 | 333 |
| Self-hosted CouchDB | 0 | 30 | 25 |
| Journal Sync (Object Storage) | 0 | 30 | 25 |

These are setup-time recommendations, not upgrade migrations. Selecting or detecting a remote does not apply them to an existing configuration unless the person is actively configuring that remote.

## Loading existing settings

`prepareSettingsForLoad` detects a blank store, completes stored settings with conservative schema fallbacks, runs ordered schema migrations, and reports the result separately from the settings value:

```ts
import { prepareSettingsForLoad } from "@vrtmrz/livesync-commonlib/settings";

const prepared = prepareSettingsForLoad(await host.loadSettings());
const settings = prepared.settings;

if (prepared.changed && !prepared.isFromFutureSchema) {
    await host.saveSettings(settings);
}

if (prepared.requiresSyncReview) {
    host.requestLocalSyncReview(prepared.reviewReasons);
}
```

Explicit stored values take precedence over every fallback. A migration therefore preserves synchronisation switches and other user choices unless a migration step documents a deliberate transformation.

`batchSaveInLiveSync` is a separate explicit choice for bounded local database batching in LiveSync mode. Both new and existing settings default to `false`; the legacy pair `liveSync: true, batchSave: true` does not enable it. The public setting property is optional for existing host settings shapes, and a missing value remains disabled. Other modes continue to use `batchSave`. Markdown settings and QR data preserve the explicit choice, while older imports without the property do not infer it from `batchSave`. Hosts should preserve both choices during ordinary mode changes and use the shared minimum and maximum delays.

The sleep preferences are included in Setup URI encoding. When an older Setup URI or stored setting does not contain either key, `allowSleepDuringSynchronisation` defaults to `false`, while `allowSleepDuringSynchronisationOnDesktop` defaults to `true`. The maintained Obsidian host therefore retains best-effort screen-awake protection on mobile but allows normal automatic sleep on desktop unless the user selects otherwise.

An existing settings store without an explicit `handleFilenameCaseSensitive` value is normalised to `false` and saved. This preserves the effective behaviour of earlier releases, where an absent value followed the case-insensitive branch. An explicit `true` or `false` value is preserved. New Vaults also select case-insensitive handling (`false`).

`isConfigured` has a separate compatibility rule from new-Vault initialisation. For a blank store, the standard service keeps the runtime unconfigured. For a non-empty legacy document without the flag, Commonlib repeats the pre-1.0 inference: a document which is equivalent to the conservative defaults remains `false`, while a stored non-default value is evidence for `true`. The inferred boolean is saved. An explicit boolean is preserved. This rule does not make a non-empty document eligible for new-Vault recommendations.

Two other values deliberately remain unset until their owning lifecycle supplies evidence: `autoAcceptCompatibleTweak` represents that no auto-accept decision has been made, and `tweakModified` represents that no tweak-change timestamp has been recorded. They are not implicit boolean defaults and are not normalised by the settings migration.

`SettingsMigrationReviewCodes.FilenameCaseSensitivityUnresolved` remains as a deprecated compatibility export for release-candidate consumers, but `prepareSettingsForLoad` no longer emits it.

The standard Commonlib `SettingService` performs this preparation automatically. Hosts which use that service can inspect `getSettingsMigrationState()` after `loadSettings()` instead of calling the function themselves.

## Host storage for device values and configuration

The host selects an asynchronous `ValueStore & ValueDeleter` for each application instance and injects it into the setting service as `deviceValues`. Commonlib does not discover `globalThis.localStorage`, create module-global storage, or fall back to another store. `setting.deviceValues` exposes the injected exact-key root. `setting.config` is an asynchronous view over the same root, scoped to the current Vault name and `additionalSuffixOfDatabaseName`; the Service Hub `config` property refers to that same view.

For an existing Web Storage layout, pass the selected storage object explicitly and use an empty adapter prefix so the service can address existing raw keys:

```ts
import { createWebStorageValueStore } from "@vrtmrz/value-store/web-storage";

const deviceValues = createWebStorageValueStore(window.localStorage, { prefix: "" });
// Supply deviceValues as the setting service's required composition dependency.
```

Use `deviceValues` for exact device-local keys, including existing keys such as `ls-setting-passphrase`. Use `config` for logical configuration keys; the service retains the established Vault and database-suffix key format. For example, the `checkpoint` key for Vault `notes` remains `notes--checkpoint` with an empty suffix and `notes-team-checkpoint` with suffix `team`. Keep the existing key names and await every read, write, and deletion:

```ts
const passphrase = await setting.deviceValues.getValue("ls-setting-passphrase");
const checkpoint = await setting.config.getValue("checkpoint");
await setting.config.setValue("checkpoint", "revision-42");
await setting.config.delete("checkpoint");
```

`getValue` returns `null` when a key is absent. Use `getObject` and `setObject` for values stored as JSON; Commonlib does not automatically reinterpret old strings or migrate entries between the exact-key root and the scoped view.

## Preparing settings for persistence and Markdown

The existing `SettingService` provides `changeConfigurationEncryption(store, passphrase?)` for hosts which edit the configuration encryption mode or device-local custom key. Await it before marking those edits as saved. It prepares one wrapper key for connection credentials, the E2EE passphrase, remote profile URIs, and the independent ID key, and serialises the change with ordinary settings saves. It rejects empty keys and unreadable existing protected items. A failed write attempts to restore the previous device key and does not send a success event. The device key and settings document use separate host writes, so this is not a guarantee of rollback after process termination or an uncertain persistence error.

When `loadSettings()` cannot validate a custom configuration key, it requests a masked key through the host's existing `confirm.askString` capability. It validates each candidate on a fresh copy and stores only a validated key before continuing initialisation. Cancellation or unavailable input stops that load without changing the saved settings. The ID-key rejection contract remains in `decryptSettings()`; loading never replaces a missing or invalid ID key with another key. ASK mode retains one successful in-memory key for ordinary saves in that launch. Hosts own the visible prompt, cancellation on disposal, and the policy which prevents database and replication work before loading completes.

`SettingService` prepares a separate settings object before calling the host's persistence handler. Object Storage credentials, CouchDB credentials, JWT values, and authentication headers share the existing `encryptedCouchDBConnection` payload. Encryption runs when any protected connection property is present, including when every CouchDB property is empty. The same policy supplies the properties encrypted, cleared before saving, and restored on loading. Older plaintext settings and encrypted payloads without newer properties remain readable.

An unavailable configuration passphrase or an empty connection-encryption result stops the save before the host's persistence handler receives the object. Remote profile URI encryption also stops on failure when a configuration passphrase is explicitly selected. The previous persisted settings remain intact. Removing all connection values clears an older encrypted payload only after it can be decrypted, preserving recovery after a failed decryption. Profile names, IDs, and selections remain ordinary settings; profile URIs are encrypted separately.

The focused `/settings` entry exports `SETTINGS_PROPERTY_POLICY` and the named `SettingPolicies` constants. Every schema property requires an explicit policy, including ordinary properties classified as `SettingPolicies.Default`. Adding a required or optional property without updating the table fails type checking. The named constants define the supported combinations of Markdown and persistence behaviour.

Hosts can use `createMarkdownSettings(settings)` to prepare an export. Its default follows `writeCredentialsForSettingSync`; an explicit boolean overrides that choice. When credentials are disabled, it omits credentials, the whole `remoteConfigurations` object, and both active-profile selections. When credentials are enabled, it retains the complete profile object and selections. Encrypted local payloads and runtime-only properties are always omitted. `mergeMarkdownSettings(incoming, current)` preserves omitted local values when importing a credential-free document.

`PersistedSettings` and `MarkdownSettings` carry preparation tags, so ordinary runtime settings cannot be passed directly to a handler which requires those types. `CredentialFreeMarkdownSettings` additionally excludes credential properties. These types check preparation boundaries; runtime policy checks and encryption tests establish the actual saved contents.

## Assessing synchronisation tweaks

Use `assessTweakCompatibility(current, preferred)` from the focused `/settings` entry when comparing the synchronisation settings advertised by two sides. The result contains immutable, whitelisted snapshots, one entry for each compared setting, and directional `adoptPreferred` and `adoptCurrent` change sets. Each entry keeps the raw value and key-presence state separately from the effective value.

```ts
import { assessTweakCompatibility } from "@vrtmrz/livesync-commonlib/settings";

const assessment = assessTweakCompatibility(localTweaks, remoteTweaks);
if (assessment.alignment === "mismatched") {
    host.requestTweakResolution(assessment);
}
```

An absent or `undefined` `handleFilenameCaseSensitive` value has the established effective value `false`. It is therefore equal to an explicit `false` value, while an explicit `true` value is mismatched. The historical defaults in `TweakValuesDefault` receive the same treatment. A missing value without a proven historical default is reported as `unadvertised` and does not by itself make `alignment` mismatched. Explicit `false`, `0`, and empty-string values remain advertised values.

The transition change sets never contain `undefined`. They can fill a missing target from an advertised source, and can use a proven effective default when that changes the target's effective value. Each transition reports `none`, `recommended`, or `required` reconstruction impact and identifies the settings which contribute that impact. Commonlib does not apply the transition, save settings, start Fetch or Rebuild, or grant permission to retry an operation.

`representationDiffers` reports raw value or key-presence differences among the compared settings. The maintained P2P transport uses this to preserve its warning for representational differences while continuing replication after ordinary tweak differences; passphrase authentication remains a separate rejection check.

## Review and downgrade boundary

A migration may report `requiresSyncReview` when automatic synchronisation should wait for a human decision. Commonlib reports that requirement but does not disable synchronisation settings, persist an acknowledgement, display a dialogue, or decide whether replication may proceed. Those are host-local responsibilities because one device must not acknowledge a safety review for another device through synchronised settings.

Settings written by a schema newer than the running Commonlib version are completed for in-memory compatibility but are not assigned an older schema version. The result has `isFromFutureSchema: true`, `changed: false`, and a review reason. A host must not persist that completed object as a downgrade migration.

The settings schema version is independent of the package version and of any remote data or protocol compatibility version. Increment it only when the stored settings shape requires an ordered migration.

## Tests owned by Commonlib

The settings lifecycle unit tests cover blank stores, representative legacy choices, migration idempotence, legacy file-name case normalisation, legacy review state, future-schema downgrade protection, and the distinction between new-Vault recommendations and stored-setting fallbacks. Credential tests cover Object Storage-only persistence, JWT and header restoration, legacy settings, removed credentials, encryption failures, conditional whole-profile Markdown export, and preservation of local values on import. Tweak-assessment tests cover effective defaults, unadvertised values, directional change sets, reconstruction impact, raw representation differences, immutable snapshots, and document-ID case behaviour. The packed-package test imports the focused `/settings` entry from a clean consumer and checks its declarations and runtime exports. Its ES2018 compile fixture checks missing policies and attempts to bypass prepared output types.

Hosts remain responsible for testing when setup is classified as new, how local review acknowledgement is stored, how replication is gated, and how their settings interface presents the result.

`SettingService.configurationEncryption.unit.spec.ts` covers key changes with ID versions 0 and 1, stale-cache avoidance, per-launch ASK reuse, concurrent saves, preparation and persistence errors, rollback reporting, custom-key input and cancellation, and retention of unreadable items. These are Commonlib-owned service contracts; Apply controls and real application restarts require downstream verification.
